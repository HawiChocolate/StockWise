# StockWise

A clean, professional inventory management app for small businesses, built with Flutter + Material 3. Demonstrates a complete CRUD workflow (Create, Read, Update, Delete) backed by local Hive storage.

## Getting Started

1. Unzip this into a folder, e.g. `stockwise/`.
2. From inside that folder, run:
   ```
   flutter pub get
   flutter run
   ```
   No `flutter create` step or build_runner/code-generation is required — the Hive `TypeAdapter` for `Product` is hand-written, so there's nothing to generate.
3. If you don't already have an `android/`, `ios/`, etc. platform folder (i.e. you unzipped just the `lib/` + config files into a fresh spot), run `flutter create .` once inside the project folder first to scaffold the platform runners, then `flutter pub get`.

## Architecture

```
lib/
  core/
    theme/        -> AppColors, AppTheme (single source of visual truth)
    constants/     -> AppConstants (low-stock threshold, categories, etc.)
    widgets/       -> CustomButton, CustomTextField, ConfirmationDialog,
                       EmptyInventoryWidget, LoadingWidget, ProductFormWidget
  models/
    product_model.dart      -> Product entity + hand-written Hive adapter
  services/
    product_service.dart    -> the ONLY class that talks to Hive directly
  providers/
    product_provider.dart   -> ChangeNotifier: CRUD, search, filter, sort, stats
  utils/
    validators.dart         -> form validation rules
    formatters.dart         -> currency/date display formatting
  screens/
    splash/                 -> SplashScreen
    home/                   -> HomeScreen + widgets/ (ProductCard, InventoryStats, SearchBarWidget)
    add_product/            -> AddProductScreen
    edit_product/           -> EditProductScreen
    product_details/        -> ProductDetailsScreen
  main.dart                 -> bootstraps Hive, injects ProductProvider
```

### Design decisions

- **State management:** `provider` (`ChangeNotifier`). All business logic (CRUD, search, sort, filtering, dashboard stats) lives in `ProductProvider` — widgets only read state and call provider methods. No CRUD logic is embedded in widget code.
- **Storage:** Hive, wrapped entirely by `ProductService`. Swapping storage engines later only means editing that one file.
- **Shared form:** Add and Edit screens both use the same `ProductFormWidget`, configured via constructor params (`initial*` values + `submitLabel`), so field layout and validation logic are never duplicated.
- **Low stock rule:** centralized as `AppConstants.lowStockThreshold` (5) and as `Product.isLowStock`, so the badge logic can't drift between the card, details screen, and dashboard stat.
- **No code generation:** the Hive `TypeAdapter` is hand-written instead of using `build_runner` + `hive_generator`, so the project runs with a single `flutter pub get` — no generation step to forget.

### Features implemented

- Full CRUD with local persistence (Hive)
- Low stock badge (< 5 units)
- Delete confirmation dialog (never deletes immediately)
- Search by product name
- Filter by category
- Sort: newest, name A-Z, quantity low→high, quantity high→low
- Dashboard stats: total products, total inventory items, low stock count
- Empty state illustration (first-run and "no search results")
- Pull-to-refresh on the home list
- SnackBar confirmations after Create / Update / Delete
- Splash screen with a short fade transition into Home

### Color palette

| Role       | Color   |
|------------|---------|
| Primary    | Blue `#1E5FFF` |
| Secondary  | Green `#1FAA59` |
| Background | White `#FAFBFF` |
| Warning    | Orange `#FF9800` |
| Error      | Red `#E53935` |

All defined once in `lib/core/theme/app_colors.dart`.
