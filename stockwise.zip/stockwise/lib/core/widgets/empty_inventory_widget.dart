import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Friendly empty state shown when there are no products yet, or
/// when a search/filter returns zero results.
class EmptyInventoryWidget extends StatelessWidget {
  final String title;
  final String message;
  final IconData icon;

  const EmptyInventoryWidget({
    super.key,
    this.title = 'No products yet',
    this.message = 'Tap the + button to add your first product to inventory.',
    this.icon = Icons.inventory_2_outlined,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 56, color: AppColors.primary),
            ),
            const SizedBox(height: 20),
            Text(title,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(
              message,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
