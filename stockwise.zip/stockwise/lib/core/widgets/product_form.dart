import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_constants.dart';
import '../../utils/validators.dart';
import 'custom_text_field.dart';
import 'custom_button.dart';

/// The single form used for BOTH creating and editing a product.
///
/// Sharing one widget between Add and Edit avoids duplicating field
/// layout, validation wiring, and styling in two places. The caller
/// controls behavior via [initial values][onSubmit] and [submitLabel].
class ProductFormWidget extends StatefulWidget {
  final String? initialProductName;
  final String? initialCategory;
  final double? initialPrice;
  final int? initialQuantity;

  final String submitLabel;
  final bool isSubmitting;

  /// Called with validated, parsed values when the user submits.
  final void Function({
    required String productName,
    required String category,
    required double price,
    required int quantity,
  }) onSubmit;

  const ProductFormWidget({
    super.key,
    this.initialProductName,
    this.initialCategory,
    this.initialPrice,
    this.initialQuantity,
    required this.submitLabel,
    required this.onSubmit,
    this.isSubmitting = false,
  });

  @override
  State<ProductFormWidget> createState() => _ProductFormWidgetState();
}

class _ProductFormWidgetState extends State<ProductFormWidget> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameController;
  late final TextEditingController _priceController;
  late final TextEditingController _quantityController;
  late String? _selectedCategory;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initialProductName ?? '');
    _priceController =
        TextEditingController(text: widget.initialPrice?.toStringAsFixed(2) ?? '');
    _quantityController =
        TextEditingController(text: widget.initialQuantity?.toString() ?? '');
    _selectedCategory = widget.initialCategory;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  void _handleSubmit() {
    final isValid = _formKey.currentState?.validate() ?? false;
    final categoryError = Validators.validateCategory(_selectedCategory);

    if (categoryError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(categoryError)),
      );
      return;
    }

    if (!isValid) return;

    widget.onSubmit(
      productName: _nameController.text.trim(),
      category: _selectedCategory!.trim(),
      price: double.parse(_priceController.text.trim()),
      quantity: int.parse(_quantityController.text.trim()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CustomTextField(
            label: 'Product Name',
            hint: 'e.g. Wireless Mouse',
            controller: _nameController,
            validator: Validators.validateProductName,
          ),
          const SizedBox(height: 20),
          Text('Category', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: _selectedCategory,
            hint: const Text('Select a category'),
            items: AppConstants.defaultCategories
                .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                .toList(),
            onChanged: (value) => setState(() => _selectedCategory = value),
          ),
          const SizedBox(height: 20),
          CustomTextField(
            label: 'Price',
            hint: '0.00',
            controller: _priceController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
            ],
            prefixIcon: const Icon(Icons.attach_money),
            validator: Validators.validatePrice,
          ),
          const SizedBox(height: 20),
          CustomTextField(
            label: 'Quantity',
            hint: '0',
            controller: _quantityController,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            prefixIcon: const Icon(Icons.numbers),
            validator: Validators.validateQuantity,
          ),
          const SizedBox(height: 32),
          CustomButton(
            label: widget.submitLabel,
            onPressed: _handleSubmit,
            isLoading: widget.isSubmitting,
          ),
        ],
      ),
    );
  }
}
