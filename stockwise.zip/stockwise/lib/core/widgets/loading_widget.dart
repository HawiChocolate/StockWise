import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Simple centered loading indicator, styled with the app's primary
/// color, used whenever the provider reports `isLoading == true`.
class LoadingWidget extends StatelessWidget {
  const LoadingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: CircularProgressIndicator(color: AppColors.primary),
    );
  }
}
