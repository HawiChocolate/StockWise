/// App-wide constant values that aren't colors or theme data.
///
/// Centralizing "magic numbers" like the low-stock threshold means
/// business rules live in one obvious place instead of being
/// scattered across widgets.
class AppConstants {
  AppConstants._();

  static const String appName = 'StockWise';
  static const String appTagline = 'Smart inventory, made simple';

  /// Products with a quantity below this value are flagged as low stock.
  static const int lowStockThreshold = 5;

  static const String productsBoxName = 'products_box';

  static const List<String> defaultCategories = [
    'Groceries',
    'Beverages',
    'Electronics',
    'Clothing',
    'Stationery',
    'Household',
    'Cosmetics',
    'Other',
  ];

  static const Duration splashDuration = Duration(seconds: 2);
}
