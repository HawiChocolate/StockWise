import 'package:flutter/material.dart';

/// Centralized color palette for the StockWise app.
///
/// Keeping every color in one place means the whole app can be
/// re-themed by editing a single file, and no screen ever needs
/// to hardcode a raw color value.
class AppColors {
  AppColors._();

  // Brand
  static const Color primary = Color(0xFF1E5FFF); // Blue
  static const Color primaryDark = Color(0xFF1443C4);
  static const Color primaryLight = Color(0xFFE8EFFF);

  static const Color secondary = Color(0xFF1FAA59); // Green
  static const Color secondaryLight = Color(0xFFE5F7EC);

  // Surfaces
  static const Color background = Color(0xFFFAFBFF);
  static const Color surface = Colors.white;
  static const Color surfaceVariant = Color(0xFFF1F4F9);

  // Status
  static const Color warning = Color(0xFFFF9800); // Orange - low stock
  static const Color warningLight = Color(0xFFFFF2E0);

  static const Color error = Color(0xFFE53935); // Red - delete / invalid
  static const Color errorLight = Color(0xFFFDEAEA);

  // Text
  static const Color textPrimary = Color(0xFF1A1D29);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textOnPrimary = Colors.white;

  // Misc
  static const Color divider = Color(0xFFE7EAF0);
  static const Color shadow = Color(0x14000000);
}
