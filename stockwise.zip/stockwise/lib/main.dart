import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'providers/product_provider.dart';
import 'screens/splash/splash_screen.dart';
import 'services/product_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();

  final productService = ProductService();
  await productService.init();

  runApp(StockWiseApp(productService: productService));
}

/// Root widget. Wires up dependency injection (the single
/// [ProductService] instance) into a [ProductProvider] that the
/// whole widget tree can read via [Provider].
class StockWiseApp extends StatelessWidget {
  final ProductService productService;

  const StockWiseApp({super.key, required this.productService});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ProductProvider(productService),
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: const SplashScreen(),
      ),
    );
  }
}
