import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../core/constants/app_constants.dart';
import '../models/product_model.dart';
import '../services/product_service.dart';

enum SortOption { newest, nameAZ, quantityLowHigh, quantityHighLow }

/// Single source of truth for product state.
///
/// This provider owns:
///  - the full product list (loaded from [ProductService])
///  - search / filter / sort state
///  - the CRUD operations widgets call into
///
/// Widgets never call [ProductService] directly and never mutate
/// product lists themselves — everything flows through here, then
/// `notifyListeners()` tells the UI to rebuild. This keeps business
/// logic completely out of the widget tree.
class ProductProvider extends ChangeNotifier {
  final ProductService _service;
  final Uuid _uuid = const Uuid();

  ProductProvider(this._service);

  List<Product> _allProducts = [];
  bool _isLoading = false;

  String _searchQuery = '';
  String? _selectedCategory;
  SortOption _sortOption = SortOption.newest;

  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String? get selectedCategory => _selectedCategory;
  SortOption get sortOption => _sortOption;

  /// The filtered + sorted list the UI should render.
  List<Product> get products {
    var result = List<Product>.from(_allProducts);

    if (_searchQuery.trim().isNotEmpty) {
      final query = _searchQuery.trim().toLowerCase();
      result = result
          .where((p) => p.productName.toLowerCase().contains(query))
          .toList();
    }

    if (_selectedCategory != null && _selectedCategory!.isNotEmpty) {
      result = result.where((p) => p.category == _selectedCategory).toList();
    }

    switch (_sortOption) {
      case SortOption.newest:
        result.sort((a, b) => b.createdDate.compareTo(a.createdDate));
        break;
      case SortOption.nameAZ:
        result.sort(
            (a, b) => a.productName.toLowerCase().compareTo(b.productName.toLowerCase()));
        break;
      case SortOption.quantityLowHigh:
        result.sort((a, b) => a.quantity.compareTo(b.quantity));
        break;
      case SortOption.quantityHighLow:
        result.sort((a, b) => b.quantity.compareTo(a.quantity));
        break;
    }

    return result;
  }

  // ---------- Dashboard stats (always computed on the full, unfiltered set) ----------
  int get totalProducts => _allProducts.length;

  int get totalInventoryItems =>
      _allProducts.fold(0, (sum, p) => sum + p.quantity);

  int get lowStockCount =>
      _allProducts.where((p) => p.quantity < AppConstants.lowStockThreshold).length;

  List<String> get availableCategories =>
      _allProducts.map((p) => p.category).toSet().toList()..sort();

  /// Looks up a single product by id from the full, unfiltered set.
  /// Used by Edit/Details screens so an active search/filter never
  /// hides the product being viewed.
  Product? getById(String id) {
    for (final product in _allProducts) {
      if (product.id == id) return product;
    }
    return null;
  }

  // ---------- Lifecycle ----------
  Future<void> loadProducts() async {
    _isLoading = true;
    notifyListeners();

    _allProducts = _service.getAllProducts();

    _isLoading = false;
    notifyListeners();
  }

  // ---------- CREATE ----------
  Future<void> addProduct({
    required String productName,
    required String category,
    required double price,
    required int quantity,
  }) async {
    final product = Product(
      id: _uuid.v4(),
      productName: productName.trim(),
      category: category.trim(),
      price: price,
      quantity: quantity,
      createdDate: DateTime.now(),
    );

    await _service.addProduct(product);
    await loadProducts();
  }

  // ---------- UPDATE ----------
  Future<void> updateProduct({
    required Product original,
    required String productName,
    required String category,
    required double price,
    required int quantity,
  }) async {
    final updated = original.copyWith(
      productName: productName.trim(),
      category: category.trim(),
      price: price,
      quantity: quantity,
    );

    await _service.updateProduct(updated);
    await loadProducts();
  }

  // ---------- DELETE ----------
  Future<void> deleteProduct(String id) async {
    await _service.deleteProduct(id);
    await loadProducts();
  }

  // ---------- Search / filter / sort ----------
  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setCategoryFilter(String? category) {
    _selectedCategory = category;
    notifyListeners();
  }

  void setSortOption(SortOption option) {
    _sortOption = option;
    notifyListeners();
  }

  void clearFilters() {
    _searchQuery = '';
    _selectedCategory = null;
    _sortOption = SortOption.newest;
    notifyListeners();
  }
}
