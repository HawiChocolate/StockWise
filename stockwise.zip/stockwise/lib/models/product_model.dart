import 'package:hive/hive.dart';

/// Core domain entity representing a single inventory item.
///
/// This is a plain, storage-agnostic model. It knows nothing about
/// Hive boxes or UI — it only knows how to represent itself and how
/// to convert to/from the primitive types Hive can persist.
class Product {
  final String id;
  final String productName;
  final String category;
  final double price;
  final int quantity;
  final DateTime createdDate;

  const Product({
    required this.id,
    required this.productName,
    required this.category,
    required this.price,
    required this.quantity,
    required this.createdDate,
  });

  bool get isLowStock => quantity < 5;

  /// Returns a copy of this product with the given fields replaced.
  /// Used by the Update flow so the id and createdDate are preserved.
  Product copyWith({
    String? productName,
    String? category,
    double? price,
    int? quantity,
  }) {
    return Product(
      id: id,
      productName: productName ?? this.productName,
      category: category ?? this.category,
      price: price ?? this.price,
      quantity: quantity ?? this.quantity,
      createdDate: createdDate,
    );
  }

  @override
  bool operator ==(Object other) => other is Product && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// Hand-written Hive adapter for [Product].
///
/// Written manually (instead of via build_runner + code generation)
/// so the project builds with zero extra tooling steps. The typeId
/// must stay unique and stable across the app.
class ProductAdapter extends TypeAdapter<Product> {
  @override
  final int typeId = 0;

  @override
  Product read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Product(
      id: fields[0] as String,
      productName: fields[1] as String,
      category: fields[2] as String,
      price: fields[3] as double,
      quantity: fields[4] as int,
      createdDate: fields[5] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, Product obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.productName)
      ..writeByte(2)
      ..write(obj.category)
      ..writeByte(3)
      ..write(obj.price)
      ..writeByte(4)
      ..write(obj.quantity)
      ..writeByte(5)
      ..write(obj.createdDate);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ProductAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
