import 'package:hive_flutter/hive_flutter.dart';
import '../core/constants/app_constants.dart';
import '../models/product_model.dart';

/// Data-access layer for products.
///
/// This is the ONLY class in the app that talks to Hive directly.
/// Providers and widgets never touch a [Box] themselves — they call
/// through here. That separation means the storage engine could be
/// swapped (e.g. for SharedPreferences or a real backend) by editing
/// this one file, with no changes needed anywhere else.
class ProductService {
  static const String _boxName = AppConstants.productsBoxName;

  Box<Product>? _box;

  /// Registers the adapter and opens the Hive box. Must be called
  /// once during app startup, before the box is used.
  Future<void> init() async {
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(ProductAdapter());
    }
    _box = await Hive.openBox<Product>(_boxName);
  }

  Box<Product> get _productBox {
    final box = _box;
    if (box == null) {
      throw StateError('ProductService.init() must be called before use.');
    }
    return box;
  }

  // ---------- CREATE ----------
  Future<void> addProduct(Product product) async {
    await _productBox.put(product.id, product);
  }

  // ---------- READ ----------
  List<Product> getAllProducts() {
    return _productBox.values.toList()
      ..sort((a, b) => b.createdDate.compareTo(a.createdDate));
  }

  Product? getProductById(String id) {
    return _productBox.get(id);
  }

  // ---------- UPDATE ----------
  Future<void> updateProduct(Product product) async {
    await _productBox.put(product.id, product);
  }

  // ---------- DELETE ----------
  Future<void> deleteProduct(String id) async {
    await _productBox.delete(id);
  }
}
