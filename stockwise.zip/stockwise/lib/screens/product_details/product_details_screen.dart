import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/confirmation_dialog.dart';
import '../../core/widgets/custom_button.dart';
import '../../core/widgets/loading_widget.dart';
import '../../models/product_model.dart';
import '../../providers/product_provider.dart';
import '../../utils/formatters.dart';
import '../edit_product/edit_product_screen.dart';

/// Read-only detail view of a single product, with Edit and Delete
/// entry points.
class ProductDetailsScreen extends StatelessWidget {
  final String productId;

  const ProductDetailsScreen({super.key, required this.productId});

  Future<void> _handleDelete(BuildContext context, Product product) async {
    final confirmed = await ConfirmationDialog.show(
      context,
      title: 'Delete product?',
      message: '"${product.productName}" will be permanently removed from inventory.',
    );

    if (!confirmed || !context.mounted) return;

    await context.read<ProductProvider>().deleteProduct(product.id);

    if (!context.mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product.productName} deleted')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final product = context.watch<ProductProvider>().getById(productId);

    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: product == null
          ? const LoadingWidget()
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  product.productName,
                                  style: Theme.of(context).textTheme.headlineMedium,
                                ),
                              ),
                              if (product.isLowStock)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: AppColors.warningLight,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: const Text(
                                    'Low Stock',
                                    style: TextStyle(
                                      color: AppColors.warning,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(product.category,
                              style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          _DetailRow(
                            icon: Icons.attach_money,
                            label: 'Price',
                            value: Formatters.currency(product.price),
                          ),
                          const Divider(height: 28),
                          _DetailRow(
                            icon: Icons.inventory_2_outlined,
                            label: 'Quantity in Stock',
                            value: '${product.quantity} units',
                          ),
                          const Divider(height: 28),
                          _DetailRow(
                            icon: Icons.category_outlined,
                            label: 'Category',
                            value: product.category,
                          ),
                          const Divider(height: 28),
                          _DetailRow(
                            icon: Icons.calendar_today_outlined,
                            label: 'Date Added',
                            value: Formatters.date(product.createdDate),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  CustomButton(
                    label: 'Edit Product',
                    icon: Icons.edit_outlined,
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => EditProductScreen(productId: product.id),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  CustomButton(
                    label: 'Delete Product',
                    icon: Icons.delete_outline,
                    variant: CustomButtonVariant.danger,
                    onPressed: () => _handleDelete(context, product),
                  ),
                ],
              ),
            ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: AppColors.primaryLight,
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: Icon(icon, size: 18, color: AppColors.primary),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Text(label, style: Theme.of(context).textTheme.bodyMedium),
        ),
        Text(value, style: Theme.of(context).textTheme.titleMedium),
      ],
    );
  }
}
