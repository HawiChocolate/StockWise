import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/confirmation_dialog.dart';
import '../../core/widgets/empty_inventory_widget.dart';
import '../../core/widgets/loading_widget.dart';
import '../../models/product_model.dart';
import '../../providers/product_provider.dart';
import '../add_product/add_product_screen.dart';
import '../edit_product/edit_product_screen.dart';
import '../product_details/product_details_screen.dart';
import 'widgets/inventory_stats.dart';
import 'widgets/product_card.dart';
import 'widgets/search_bar_widget.dart';

/// Main screen of the app: dashboard stats, search/filter, and the
/// scrollable product list. Orchestrates navigation to Add / Edit /
/// Details, but delegates all state changes to [ProductProvider].
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProductProvider>().loadProducts();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _openFilterSheet(ProductProvider provider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => FilterSortSheet(
        categories: provider.availableCategories,
        selectedCategory: provider.selectedCategory,
        selectedSort: provider.sortOption,
        onCategorySelected: (category) {
          provider.setCategoryFilter(category);
          Navigator.pop(context);
        },
        onSortSelected: (option) {
          provider.setSortOption(option);
          Navigator.pop(context);
        },
        onClear: () {
          provider.clearFilters();
          _searchController.clear();
          Navigator.pop(context);
        },
      ),
    );
  }

  Future<void> _handleDelete(BuildContext context, Product product) async {
    final confirmed = await ConfirmationDialog.show(
      context,
      title: 'Delete product?',
      message: '"${product.productName}" will be permanently removed from inventory.',
    );

    if (!confirmed || !context.mounted) return;

    await context.read<ProductProvider>().deleteProduct(product.id);

    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product.productName} deleted')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProductProvider>();
    final hasActiveFilters =
        provider.selectedCategory != null || provider.sortOption != SortOption.newest;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const AddProductScreen()),
        ),
        child: const Icon(Icons.add),
      ),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () => context.read<ProductProvider>().loadProducts(),
        child: provider.isLoading
            ? const LoadingWidget()
            : CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          SearchBarWidget(
                            controller: _searchController,
                            onChanged: provider.setSearchQuery,
                            onFilterTap: () => _openFilterSheet(provider),
                            hasActiveFilters: hasActiveFilters,
                          ),
                          const SizedBox(height: 16),
                          InventoryStats(
                            totalProducts: provider.totalProducts,
                            totalInventoryItems: provider.totalInventoryItems,
                            lowStockCount: provider.lowStockCount,
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (provider.products.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: EmptyInventoryWidget(
                        title: provider.totalProducts == 0
                            ? 'No products yet'
                            : 'No matching products',
                        message: provider.totalProducts == 0
                            ? 'Tap the + button to add your first product to inventory.'
                            : 'Try a different search term or clear your filters.',
                      ),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                      sliver: SliverList.separated(
                        itemCount: provider.products.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final product = provider.products[index];
                          return ProductCard(
                            product: product,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ProductDetailsScreen(productId: product.id),
                              ),
                            ),
                            onEdit: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => EditProductScreen(productId: product.id),
                              ),
                            ),
                            onDelete: () => _handleDelete(context, product),
                          );
                        },
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
