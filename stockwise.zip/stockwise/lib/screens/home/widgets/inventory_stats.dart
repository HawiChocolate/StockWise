import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

/// Row of dashboard summary cards: total products, total items in
/// stock, and how many are running low. Purely presentational.
class InventoryStats extends StatelessWidget {
  final int totalProducts;
  final int totalInventoryItems;
  final int lowStockCount;

  const InventoryStats({
    super.key,
    required this.totalProducts,
    required this.totalInventoryItems,
    required this.lowStockCount,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatCard(
            label: 'Products',
            value: '$totalProducts',
            icon: Icons.category_outlined,
            color: AppColors.primary,
            backgroundColor: AppColors.primaryLight,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatCard(
            label: 'Total Items',
            value: '$totalInventoryItems',
            icon: Icons.inventory_2_outlined,
            color: AppColors.secondary,
            backgroundColor: AppColors.secondaryLight,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatCard(
            label: 'Low Stock',
            value: '$lowStockCount',
            icon: Icons.warning_amber_rounded,
            color: AppColors.warning,
            backgroundColor: AppColors.warningLight,
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final Color backgroundColor;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}
