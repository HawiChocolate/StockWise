import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../providers/product_provider.dart';

/// Search input plus a filter/sort trigger button. Emits state
/// changes upward via callbacks; holds no product data itself.
class SearchBarWidget extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onFilterTap;
  final bool hasActiveFilters;

  const SearchBarWidget({
    super.key,
    required this.controller,
    required this.onChanged,
    required this.onFilterTap,
    this.hasActiveFilters = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            onChanged: onChanged,
            decoration: const InputDecoration(
              hintText: 'Search products...',
              prefixIcon: Icon(Icons.search, color: AppColors.textSecondary),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Container(
          decoration: BoxDecoration(
            color: hasActiveFilters ? AppColors.primary : AppColors.surfaceVariant,
            borderRadius: BorderRadius.circular(14),
          ),
          child: IconButton(
            onPressed: onFilterTap,
            icon: Icon(
              Icons.tune_rounded,
              color: hasActiveFilters ? Colors.white : AppColors.textSecondary,
            ),
            tooltip: 'Filter & sort',
          ),
        ),
      ],
    );
  }
}

/// Bottom sheet that lets the user filter by category and choose a
/// sort order. Kept in this file since it's tightly coupled to the
/// search bar's "filter" trigger.
class FilterSortSheet extends StatelessWidget {
  final List<String> categories;
  final String? selectedCategory;
  final SortOption selectedSort;
  final ValueChanged<String?> onCategorySelected;
  final ValueChanged<SortOption> onSortSelected;
  final VoidCallback onClear;

  const FilterSortSheet({
    super.key,
    required this.categories,
    required this.selectedCategory,
    required this.selectedSort,
    required this.onCategorySelected,
    required this.onSortSelected,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Filter & Sort', style: Theme.of(context).textTheme.titleLarge),
                TextButton(onPressed: onClear, child: const Text('Clear all')),
              ],
            ),
            const SizedBox(height: 12),
            Text('Category', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('All'),
                  selected: selectedCategory == null,
                  onSelected: (_) => onCategorySelected(null),
                ),
                for (final category in categories)
                  ChoiceChip(
                    label: Text(category),
                    selected: selectedCategory == category,
                    onSelected: (_) => onCategorySelected(category),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            Text('Sort by', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _sortChip(context, 'Newest', SortOption.newest),
                _sortChip(context, 'Name A-Z', SortOption.nameAZ),
                _sortChip(context, 'Qty: Low to High', SortOption.quantityLowHigh),
                _sortChip(context, 'Qty: High to Low', SortOption.quantityHighLow),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sortChip(BuildContext context, String label, SortOption option) {
    return ChoiceChip(
      label: Text(label),
      selected: selectedSort == option,
      onSelected: (_) => onSortSelected(option),
    );
  }
}
