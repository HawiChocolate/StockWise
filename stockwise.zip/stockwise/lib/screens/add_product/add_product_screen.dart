import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/widgets/product_form.dart';
import '../../providers/product_provider.dart';

/// Screen for creating a new product. Delegates the actual form
/// UI to the shared [ProductFormWidget] and only owns the
/// "is this submit in flight" state plus calling the provider.
class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  bool _isSubmitting = false;

  Future<void> _handleSubmit({
    required String productName,
    required String category,
    required double price,
    required int quantity,
  }) async {
    setState(() => _isSubmitting = true);

    await context.read<ProductProvider>().addProduct(
          productName: productName,
          category: category,
          price: price,
          quantity: quantity,
        );

    if (!mounted) return;
    setState(() => _isSubmitting = false);

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$productName added to inventory')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Product')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ProductFormWidget(
          submitLabel: 'Save Product',
          isSubmitting: _isSubmitting,
          onSubmit: _handleSubmit,
        ),
      ),
    );
  }
}
