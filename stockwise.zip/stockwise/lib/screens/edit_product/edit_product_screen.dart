import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/widgets/loading_widget.dart';
import '../../core/widgets/product_form.dart';
import '../../providers/product_provider.dart';

/// Screen for editing an existing product. Looks the product up by
/// id from the provider, pre-fills the shared form, and saves via
/// `updateProduct` on submit.
class EditProductScreen extends StatefulWidget {
  final String productId;

  const EditProductScreen({super.key, required this.productId});

  @override
  State<EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  bool _isSubmitting = false;

  Future<void> _handleSubmit({
    required String productName,
    required String category,
    required double price,
    required int quantity,
  }) async {
    final provider = context.read<ProductProvider>();
    final original = provider.getById(widget.productId);
    if (original == null) return;

    setState(() => _isSubmitting = true);

    await provider.updateProduct(
      original: original,
      productName: productName,
      category: category,
      price: price,
      quantity: quantity,
    );

    if (!mounted) return;
    setState(() => _isSubmitting = false);

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$productName updated')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProductProvider>();
    final product = provider.getById(widget.productId);

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Product')),
      body: product == null
          ? const LoadingWidget()
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ProductFormWidget(
                initialProductName: product.productName,
                initialCategory: product.category,
                initialPrice: product.price,
                initialQuantity: product.quantity,
                submitLabel: 'Update Product',
                isSubmitting: _isSubmitting,
                onSubmit: _handleSubmit,
              ),
            ),
    );
  }
}
