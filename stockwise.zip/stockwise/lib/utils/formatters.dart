import 'package:intl/intl.dart';

/// Formatting helpers so currency and date display stay identical
/// everywhere they appear (cards, details screen, dashboard).
class Formatters {
  Formatters._();

  static final NumberFormat _currencyFormat =
      NumberFormat.currency(symbol: '\$', decimalDigits: 2);

  static final DateFormat _dateFormat = DateFormat('MMM d, yyyy');

  static String currency(double value) => _currencyFormat.format(value);

  static String date(DateTime value) => _dateFormat.format(value);
}
