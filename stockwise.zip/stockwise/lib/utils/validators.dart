/// Pure, stateless validation functions for the product form.
///
/// Kept separate from widgets so validation rules are unit-testable
/// and reusable between the Add and Edit screens.
class Validators {
  Validators._();

  static String? validateProductName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Product name is required';
    }
    if (value.trim().length < 2) {
      return 'Product name is too short';
    }
    return null;
  }

  static String? validateCategory(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Category is required';
    }
    return null;
  }

  static String? validatePrice(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Price is required';
    }
    final parsed = double.tryParse(value.trim());
    if (parsed == null) {
      return 'Enter a valid numeric price';
    }
    if (parsed < 0) {
      return 'Price cannot be negative';
    }
    return null;
  }

  static String? validateQuantity(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Quantity is required';
    }
    final parsed = int.tryParse(value.trim());
    if (parsed == null) {
      return 'Enter a valid whole number';
    }
    if (parsed < 0) {
      return 'Quantity cannot be negative';
    }
    return null;
  }
}
